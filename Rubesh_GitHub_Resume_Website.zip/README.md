# Rubesh Resume Website

## Upload to GitHub Pages

1. Create a new repository in GitHub
2. Upload the `index.html` file
3. Go to Settings → Pages
4. Select:
   - Branch: main
   - Folder: /root
5. Click Save

Your website link will look like:
https://yourusername.github.io/repository-name/
